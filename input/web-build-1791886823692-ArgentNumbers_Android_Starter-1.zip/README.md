# Argent Numbers — Android starter project

This is a first Android prototype for the Argent Numbers emergency-help app.

## Current prototype features
- Android app screen with an emergency call shortcut for 999.
- Hotline cards for 999, 102, 333 and 1098.
- Uses Android's location permission flow and attempts to read the last known location.
- Opens a map app for nearby-place searching.
- Uses the phone dialler rather than placing calls automatically.

## Important limitations
- This is source code, not a precompiled APK.
- Local police station, fire station, government hospital, ambulance and electricity complaint-centre directories are not yet populated.
- Nearby map search relies on an installed map app and internet access.
- Location may be unavailable until GPS/location is enabled and the device has a recent location fix.
- Confirm hotline numbers and local contact data against official sources before public release.
- The first version has not been built or tested on a physical phone.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle to sync and download dependencies.
4. Connect an Android phone or start an emulator and press Run to test.
5. To create an installable debug APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the location of the generated APK.

## Next development steps
1. Add a verified, updateable Bangladesh service directory.
2. Filter real facilities by GPS distance and show address, source and last-verified date.
3. Add Bangla/English switching and district/upazila search.
4. Test location permission denial, no GPS, offline use and phone-call flows.
5. Publish only after contact data and safety behaviour have been checked.
